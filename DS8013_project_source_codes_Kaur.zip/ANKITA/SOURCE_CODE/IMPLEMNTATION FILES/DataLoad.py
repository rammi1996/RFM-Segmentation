import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from os import listdir
import cv2
# Load the Data 


#main_path=r"D:\data\Downloads\archive (9)\brain_tumor_dataset"
main_path=r"D:\data\Downloads\archive (10)\brain_tumor_dataset"
yes_images_dir = r'D:\data\Downloads\archive (10)\brain_tumor_dataset\yes'
no_images_dir = r'D:\data\Downloads\archive (10)\brain_tumor_dataset\no'
dir_list = [yes_images_dir, no_images_dir]
image_size = (256, 256)  # Specify the desired image size

def load_data(dir_list, image_size):
    X = []
    y = []
    image_height, image_width = image_size
    
    # Load the data into directories
    for directory in dir_list:
        for filename in listdir(directory):
            image = cv2.imread(directory + '/' + filename)
            image = cv2.resize(image, dsize=(image_height, image_width),interpolation=cv2.INTER_CUBIC)
            image = image / 255.0
            X.append(image)
            if directory.endswith('yes'):
                y.append([1])
            else:
                y.append([0])
     
    X = np.array(X)
    y = np.array(y)
    
    # Shuffle the X,y
    print(f'Number of examples is: {len(X)}')
    print(f'X shape is: {X.shape}')
    print(f'y shape is: {y.shape}')
    
    return X, y

X, y = load_data(dir_list, image_size)